package model;

public enum Tool {
	TRASH, RECYCLE, COMPOST
}
