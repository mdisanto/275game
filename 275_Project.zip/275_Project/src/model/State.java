package model;

public enum State {
	NEUTRAL, INVINCIBLE, SPEEDUP
}
